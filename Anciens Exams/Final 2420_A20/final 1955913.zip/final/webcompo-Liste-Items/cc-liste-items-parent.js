class CcListeItemsParent extends HTMLElement {
    constructor() {
        super();//heriter les attributs et methodes de HTMLElement

        //obtient le shadow root pour recevoir le code encapsule'
        this._root = this.attachShadow({ mode: 'open' });

         //proprietes
         this.affiche_id = new Boolean("false");
         this.affiche_attributs = new Boolean("false");

        //donnees
        this.items = [];
    }


    //lorsque connecte'
    connectedCallback() {
        //defini le code encapsule'
        this._root.innerHTML = `
        <style>
        .vertical-container {
            display: grid;
            grid-auto-flow: row; 
            padding: 10px;
          }
        .horizontal-container {
            display: grid;
            grid-auto-flow: column; 
            padding: 10px;
            background-color: #33b5e5;
            color: #ffffff;
            margin: 5px;
          } 
          .selected{
            background-color: #808080 !important;;
      }         
          .horizontal-grid-item {
            font-size: 30px;
            text-align: center;
            font-family: Arial, Helvetica, sans-serif;
          }

          .horizontal-grid-item:active {
            background-color: #808080;
            color:#000000
          }

          .horizontal-grid-item:hover {
            opacity:60%;
            cursor:pointer;
          }

            h1, h2 {
                padding: 10px;
                color:black;
                font-family: Arial, Helvetica, sans-serif;
            }
        </style>
        <h1>Titre de la liste d'items</h1>
        <h2>Soustitre de la liste d'items</h2>

        <template id="template-item"></template>
        <div id="result" class="vertical-container"></div>

    `;
        this.setLayout();
    }

    setLayout() {

        //cree les variables avec les fragments du code encapsule'
        this.templateContent = this._root.querySelector('#template-item').content;
        this.result = this._root.querySelector('#result');
        //clone le templateContent
        const clone = document.importNode(this.templateContent, true);

        // Object.keys(item).length            
 
        this.items.map(item => {
            //cree une div container pour l'item
            const div_item = document.createElement("div");

            div_item.setAttribute("id", item.id);
            div_item.setAttribute("class", "horizontal-container");
            div_item.setAttribute("style", "background-color: #33b5e5;");

            //creer des balises pour les attributs de l' item
            var start=true;
            for (var i in item.attributs) {
                var balise;
                //met 'a jour le clone avec les donnees de chaque vehicule si demande'
                if (start) {
                    //cree une tag h2 pour l'attribut_1;
                    balise = document.createElement("h2");
                } else {
                    //cree une tag h2 pour l'attribut_1;
                    balise = document.createElement("p");
                }
                start=false;
                balise.innerHTML = item.attributs[i];
                balise.setAttribute("id", item.attributs[i]);
                balise.setAttribute("class", "horizontal-grid-item");
                //ajoute la balise au container
                div_item.appendChild(balise);
               
            }
            //ajoute le container au clone
            clone.appendChild(div_item);
           
        });
        //ajoute le clone au shadow DOM
        this.result.appendChild(clone);

    }

    static get observedAttributes() {
        return ["items"];
    }
    attributeChangedCallback(name, oldValue, newValue) {

        if (name === 'items') {
            this.items = newValue;
        }

    }/**/

 


}//fin de la classe

//registre de la classe en dehors de la classe
window.customElements.define('cc-liste-items-parent', CcListeItemsParent); // (tag , instance)






