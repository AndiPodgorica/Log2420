var donnees = JSON.stringify(items);

class CcListeItemsEnfant extends CcListeItemsParent {

    constructor() {
    super(); //heriter les attributs et methodes de HTMLElement
    super.items= [
        {
            id: 'Frigo1',
            attributs: 
            {
                attribut_1 :'Burger',
                attribut_2: 'salade',
                attribut_3: 'portion:2',
                attribut_4: 'date: 2jr',
                attribut_5: 'allergeniques:aucun',
          
            }
        }, 
        {
            id: 'Frigo2',
            attributs: 
            {
                attribut_1 :'gateau',
                attribut_2: 'creme',
                attribut_3: 'portion:2',
                attribut_4: 'date: 2jr',
                attribut_5: 'allergeniques:lacotse',
            }
        },
        {
            id: 'Frigo3',
            attributs: 
            {
                attribut_1 :'gateau au chocolat',
                attribut_2: 'chocolat',
                attribut_3: 'portion:1',
                attribut_4: 'date: 5jr',
                attribut_5: 'allergeniques:lacotse',
            }
        },
        {
            id: 'Frigo4',
            attributs: 
            {
                attribut_1 :'salade grecque',
                attribut_2: 'salade',
                attribut_3: 'portion:3',
                attribut_4: 'date: 2jr',
                attribut_5: 'allergeniques:aucun',
            }
        },
        {
            id: 'Frigo5',
            attributs: 
            {
                attribut_1 :'salade cesar',
                attribut_2: 'salade et sauce',
                attribut_3: 'portion:5',
                attribut_4: 'date: 2jr',
                attribut_5: 'allergeniques:sauce allergene',
            }
        },{
            id: 'Frigo6',
            attributs: 
            {
                attribut_1 :'patee chinois',
                attribut_2: 'patates',
                attribut_3: 'portion:3',
                attribut_4: 'date: 2jr',
                attribut_5: 'allergeniques:aucun',
            }
        }
    ]; 

    


    }


}//fin de la classe
        
//registre de la classe en dehors de la classe
window.customElements.define('cc-liste-items-enfant', CcListeItemsEnfant); // (tag , instance)