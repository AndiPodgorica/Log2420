class CcListeItemsEnfant extends CcListeItemsParent {

    constructor() {
    super(); //heriter les attributs et methodes de HTMLElement
    super.items= [
        {
            id: 'item_1',
            attributs: 
            {
                attribut_2: 'item_1_attribut_1',
                attribut_3: 'item_1_attribut_2',
                attribut_4: 'item_1_attribut_3'
            }
        }, 
        {
            id: 'item_2',
            attributs: 
            {
                attribut_1: 'item_2_attribut_1',
                attribut_2: 'item_2_attribut_2',
                attribut_3: 'item_2_attribut_3'
            }
        },
        {
            id: 'item_3',
            attributs: 
            {
                attribut_1: 'item_3_attribut_1',
                attribut_2: 'item_3_attribut_2',
                attribut_3: 'item_3_attribut_3'
            }
        },
        {
            id: 'item_4',
            attributs: 
            {
                attribut_1: 'item_4_attribut_1',
                attribut_2: 'item_4_attribut_2',
                attribut_3: 'item_4_attribut_3'
            }
        },
        {
            id: 'item_5',
            attributs: 
            {
                attribut_1: 'item_5_attribut_1',
                attribut_2: 'item_5_attribut_2',
                attribut_3: 'item_5_attribut_3'
            }
        },{
            id: 'item_6',
            attributs: 
            {
                attribut_1: 'item_6_attribut_1',
                attribut_2: 'item_6_attribut_2',
                attribut_3: 'item_6_attribut_3'
            }
        }
    ]; 



    }


}//fin de la classe
        
//registre de la classe en dehors de la classe
window.customElements.define('cc-liste-items-enfant', CcListeItemsEnfant); // (tag , instance)